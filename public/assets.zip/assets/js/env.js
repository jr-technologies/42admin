var domain = "http://"+window.location.hostname+"/42admin/public/";
var api = "api/v1/";
var apiPath = domain+api;